# LiveDraft Arena Docker

Docker configuration for LiveDraft Arena.

## Usage

```bash
# Build and run
docker-compose up
```