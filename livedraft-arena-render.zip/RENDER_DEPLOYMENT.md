# LiveDraft Arena - Render Deployment Guide

## 📦 What to Upload

Upload the file: `livedraft-arena-render.zip`

This ZIP contains the entire project including:
- Rust backend service (`service/`)
- Smart contracts (`contracts/`)
- Dockerfile for production build

## 🚀 Render Deployment Steps

### 1. Create New Web Service

1. Go to [Render Dashboard](https://dashboard.render.com)
2. Click "New +" → "Web Service"
3. Choose "Deploy an existing image from a registry" → "No, I want to build from source code"
4. Select "Upload from computer"
5. Upload `livedraft-arena-render.zip`

### 2. Configure Service

**Basic Settings:**
- **Name**: `livedraft-arena-api`
- **Region**: `Oregon (US West)` or closest to your users
- **Branch**: Leave default
- **Root Directory**: Leave empty (uses project root)

**Build & Deploy:**
- **Runtime**: `Docker`
- **Build Command**: Leave empty (Docker handles build)
- **Start Command**: `./livedraft-arena-service`

**Advanced Settings:**
- **Port**: `8080`
- **Health Check Path**: `/health`

### 3. Environment Variables

**Required:**
```
LIVEDRAFT_APP_ID=placeholder_app_id_for_deployment
```

**Optional (with defaults):**
```
PORT=8080
BIND_ADDRESS=0.0.0.0
CORS_ORIGINS=*
RUST_LOG=info
```

### 4. Deploy

1. Click "Create Web Service"
2. Wait for build and deployment (5-10 minutes)
3. Service will be available at: `https://livedraft-arena-api.onrender.com`

## 🔍 Verification

After deployment, test these endpoints:

**Health Check:**
```bash
curl https://livedraft-arena-api.onrender.com/health
# Expected: {"status":"ok"}
```

**GraphQL Introspection:**
```bash
curl -X POST https://livedraft-arena-api.onrender.com/graphql \
  -H "Content-Type: application/json" \
  -d '{"query": "{ __schema { types { name } } }"}'
# Expected: GraphQL schema response
```

**GraphQL Playground:**
Visit: `https://livedraft-arena-api.onrender.com/playground`

## 🔧 Configuration Summary

| Setting | Value |
|---------|-------|
| **Upload** | `livedraft-arena-render.zip` |
| **Start Command** | `./livedraft-arena-service` |
| **Port** | `8080` |
| **Health Check** | `/health` |
| **Environment** | `LIVEDRAFT_APP_ID=placeholder_app_id_for_deployment` |

## 🌐 Frontend Integration

After successful deployment, update your frontend:

**Vercel Environment Variable:**
```
VITE_BACKEND_GRAPHQL_URL=https://livedraft-arena-api.onrender.com/graphql
```

**Local Development:**
```bash
# In frontend/.env.local
VITE_BACKEND_GRAPHQL_URL=https://livedraft-arena-api.onrender.com/graphql
```

## ✅ Expected Result

Opening `https://livedraft-arena-api.onrender.com/graphql` will return a valid GraphQL response, enabling the frontend "Create Room" feature to work immediately.

The service includes:
- ✅ POST GraphQL endpoint at `/graphql`
- ✅ Server listening on `0.0.0.0:8080`
- ✅ CORS enabled for all origins
- ✅ Health check at `/health`
- ✅ GraphQL playground at `/playground`