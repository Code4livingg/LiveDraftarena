// LiveDraft Arena Frontend Configuration
// Vercel environment variable configuration for production deployment

const backendUrl = import.meta.env.VITE_BACKEND_GRAPHQL_URL;

if (!backendUrl) {
  throw new Error(
    "VITE_BACKEND_GRAPHQL_URL is required. Set it in Vercel → Project Settings → Environment Variables to your backend GraphQL endpoint (e.g., https://your-backend.com/graphql)"
  );
}

export const GRAPHQL_ENDPOINT = backendUrl;